package com.example.qzy;

public class Question {
    String Qid;
    String Category;
    String Question;
    String OptionA;
    String OptionB;
    String OptionC;
    String OptionD;
    String Answer;

}
